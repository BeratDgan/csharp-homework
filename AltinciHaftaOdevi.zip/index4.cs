using System;

class Otopark
{
    private string[,] parkYerleri;

    public Otopark(int katSayisi, int yerSayisi)
    {
        parkYerleri = new string[katSayisi, yerSayisi];
        for (int i = 0; i < katSayisi; i++)
            for (int j = 0; j < yerSayisi; j++)
                parkYerleri[i, j] = "Empty";
    }

    public string this[int kat, int yer]
    {
        get
        {
            if (kat < 0 || kat >= parkYerleri.GetLength(0) || yer < 0 || yer >= parkYerleri.GetLength(1))
                return "Hatalı giriş!";
            return parkYerleri[kat, yer];
        }
        set
        {
            if (kat < 0 || kat >= parkYerleri.GetLength(0) || yer < 0 || yer >= parkYerleri.GetLength(1))
                Console.WriteLine("Hatalı giriş!");
            else
                parkYerleri[kat, yer] = value;
        }
    }
}

class Program
{
    static void Main()
    {
        Otopark otopark = new Otopark(3, 5);

        otopark[0, 0] = "34ABC123";
        otopark[1, 2] = "35XYZ456";

        Console.WriteLine(otopark[0, 0]); // 34ABC123
        Console.WriteLine(otopark[1, 2]); // 35XYZ456
        Console.WriteLine(otopark[2, 4]); // Empty
        Console.WriteLine(otopark[3, 5]); // Hatalı giriş!
    }
}