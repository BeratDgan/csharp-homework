using System;
using System.Collections.Generic;

class OgrenciNotlari
{
    private Dictionary<string, int> notlar = new Dictionary<string, int>();

    public int this[string dersAdi]
    {
        get
        {
            if (notlar.ContainsKey(dersAdi))
                return notlar[dersAdi];
            else
                throw new Exception($"'{dersAdi}' dersi bulunamadı.");
        }
        set
        {
            notlar[dersAdi] = value;
        }
    }
}

class Program
{
    static void Main()
    {
        OgrenciNotlari notSistemi = new OgrenciNotlari();
        notSistemi["Matematik"] = 85;
        notSistemi["Fizik"] = 90;

        Console.WriteLine("Matematik notu: " + notSistemi["Matematik"]);
        try
        {
            Console.WriteLine("Kimya notu: " + notSistemi["Kimya"]);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}