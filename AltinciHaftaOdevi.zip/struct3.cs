using System;

struct GPSKonum
{
    public double Latitude { get; private set; }
    public double Longitude { get; private set; }

    public GPSKonum(double latitude, double longitude)
    {
        Latitude = latitude;
        Longitude = longitude;
    }

    public double Mesafe(GPSKonum other)
    {
        const double EarthRadiusKm = 6371;
        double dLat = DegToRad(other.Latitude - this.Latitude);
        double dLon = DegToRad(other.Longitude - this.Longitude);

        double a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                   Math.Cos(DegToRad(this.Latitude)) * Math.Cos(DegToRad(other.Latitude)) *
                   Math.Sin(dLon / 2) * Math.Sin(dLon / 2);

        double c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
        return EarthRadiusKm * c;
    }

    private static double DegToRad(double degree)
    {
        return degree * (Math.PI / 180);
    }

    public override string ToString()
    {
        return $"Enlem: {Latitude}, Boylam: {Longitude}";
    }
}

class Program
{
    static void Main()
    {
        GPSKonum konum1 = new GPSKonum(41.0082, 28.9784); // İstanbul
        GPSKonum konum2 = new GPSKonum(40.730610, -73.935242); // New York

        Console.WriteLine($"Konum 1: {konum1}");
        Console.WriteLine($"Konum 2: {konum2}");
        Console.WriteLine($"Mesafe: {konum1.Mesafe(konum2):F2} km"); // 8031.67 km
    }
}