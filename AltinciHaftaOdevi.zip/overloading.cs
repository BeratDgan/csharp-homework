using System;

class MatematikselIslemler
{
    // İki tam sayıyı toplayan metod
    public int Topla(int a, int b)
    {
        return a + b;
    }

    // Üç tam sayıyı toplayan metod
    public int Topla(int a, int b, int c)
    {
        return a + b + c;
    }

    // Bir dizi (array) tam sayıyı toplayan metod
    public int Topla(int[] sayilar)
    {
        int toplam = 0;
        foreach (int sayi in sayilar)
        {
            toplam += sayi;
        }
        return toplam;
    }
}

class Program
{
    static void Main()
    {
        MatematikselIslemler mi = new MatematikselIslemler();
        
        Console.WriteLine("İki sayının toplamı: " + mi.Topla(5, 10));
        Console.WriteLine("Üç sayının toplamı: " + mi.Topla(5, 10, 15));
        Console.WriteLine("Dizinin toplamı: " + mi.Topla(new int[] { 1, 2, 3, 4, 5 }));
    }
}