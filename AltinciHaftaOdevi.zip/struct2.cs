using System;

struct KarmaSayi
{
    public double Real { get; private set; }
    public double Imaginary { get; private set; }

    public KarmaSayi(double real, double imaginary)
    {
        Real = real;
        Imaginary = imaginary;
    }

    public KarmaSayi Topla(KarmaSayi other)
    {
        return new KarmaSayi(this.Real + other.Real, this.Imaginary + other.Imaginary);
    }

    public KarmaSayi Cikar(KarmaSayi other)
    {
        return new KarmaSayi(this.Real - other.Real, this.Imaginary - other.Imaginary);
    }

    public override string ToString()
    {
        return $"{Real} + {Imaginary}i";
    }
}

class Program
{
    static void Main()
    {
        KarmaSayi sayi1 = new KarmaSayi(3, 4);
        KarmaSayi sayi2 = new KarmaSayi(1, 2);

        KarmaSayi toplam = sayi1.Topla(sayi2);
        KarmaSayi fark = sayi1.Cikar(sayi2);

        Console.WriteLine($"Sayı 1: {sayi1}"); // 3 + 4i
        Console.WriteLine($"Sayı 2: {sayi2}"); // 1 + 2i
        Console.WriteLine($"Toplam: {toplam}"); // 4 + 6i
        Console.WriteLine($"Fark: {fark}"); // 2 + 2i
    }
}