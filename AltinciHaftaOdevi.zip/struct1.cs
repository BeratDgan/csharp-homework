using System;

struct Zaman
{
    public int Hour { get; private set; }
    public int Minute { get; private set; }

    public Zaman(int hour, int minute)
    {
        Hour = (hour >= 0 && hour < 24) ? hour : 0;
        Minute = (minute >= 0 && minute < 60) ? minute : 0;
    }

    public int ToplamDakika()
    {
        return Hour * 60 + Minute;
    }

    public int Fark(Zaman other)
    {
        return Math.Abs(this.ToplamDakika() - other.ToplamDakika());
    }

    public override string ToString()
    {
        return $"{Hour:D2}:{Minute:D2}";
    }
}

class Program
{
    static void Main()
    {
        Zaman zaman1 = new Zaman(14, 30);
        Zaman zaman2 = new Zaman(12, 45);
        Console.WriteLine($"Zaman 1: {zaman1}"); // Zaman 1: 14:30
        Console.WriteLine($"Zaman 2: {zaman2}"); // Zaman 2: 12:45
        Console.WriteLine($"Toplam dakika (Zaman 1): {zaman1.ToplamDakika()}"); // 870
        Console.WriteLine($"Zaman farkı: {zaman1.Fark(zaman2)} dakika"); // 105
    }
}