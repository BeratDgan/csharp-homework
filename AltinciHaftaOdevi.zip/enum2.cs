using System;

enum HavaDurumu
{
    Sunny,
    Rainy,
    Cloudy,
    Stormy
}

class HavaTahmini
{
    public string Tavsiye(HavaDurumu durum)
    {
        switch (durum)
        {
            case HavaDurumu.Sunny:
                return "Güneş kremi sürün ve açık havanın keyfini çıkarın.";
            case HavaDurumu.Rainy:
                return "Şemsiye alın ve yağmura hazırlıklı olun.";
            case HavaDurumu.Cloudy:
                return "Hava serin olabilir, yanınıza bir ceket alın.";
            case HavaDurumu.Stormy:
                return "Dışarı çıkmaktan kaçının, güvenli bir yerde kalın.";
            default:
                return "Bilinmeyen hava durumu.";
        }
    }
}

class Program
{
    static void Main()
    {
        HavaTahmini tahmin = new HavaTahmini();

        Console.WriteLine(tahmin.Tavsiye(HavaDurumu.Sunny));   // Güneş kremi sürün...
        Console.WriteLine(tahmin.Tavsiye(HavaDurumu.Rainy));   // Şemsiye alın...
        Console.WriteLine(tahmin.Tavsiye(HavaDurumu.Stormy));  // Dışarı çıkmaktan kaçının...
    }
}