using System;

class SatrancTahtasi
{
    private string[,] tahtasi = new string[8, 8];

    public SatrancTahtasi()
    {
        for (int i = 0; i < 8; i++)
            for (int j = 0; j < 8; j++)
                tahtasi[i, j] = "Boş";
    }

    public string this[int satir, int sutun]
    {
        get
        {
            if (satir < 0 || satir >= 8 || sutun < 0 || sutun >= 8)
                return "Hatalı kare!";
            return tahtasi[satir, sutun];
        }
        set
        {
            if (satir < 0 || satir >= 8 || sutun < 0 || sutun >= 8)
                Console.WriteLine("Hatalı kare!");
            else
                tahtasi[satir, sutun] = value;
        }
    }
}

class Program
{
    static void Main()
    {
        SatrancTahtasi tahtasi = new SatrancTahtasi();
        tahtasi[0, 0] = "Kale";
        tahtasi[7, 7] = "Vezir";

        Console.WriteLine(tahtasi[0, 0]); // Kale
        Console.WriteLine(tahtasi[7, 7]); // Vezir
        Console.WriteLine(tahtasi[8, 8]); // Hatalı kare!
    }
}