using System;

class Kitaplik
{
    private string[] kitaplar;

    public Kitaplik(int kapasite)
    {
        kitaplar = new string[kapasite];
        for (int i = 0; i < kapasite; i++)
        {
            kitaplar[i] = "Boş";
        }
    }

    public string this[int indeks]
    {
        get
        {
            if (indeks < 0 || indeks >= kitaplar.Length)
                return "Hatalı indeks!";
            return kitaplar[indeks];
        }
        set
        {
            if (indeks < 0 || indeks >= kitaplar.Length)
                Console.WriteLine("Hatalı indeks!");
            else
                kitaplar[indeks] = value;
        }
    }
}

class Program
{
    static void Main()
    {
        Kitaplik kitaplik = new Kitaplik(5);
        kitaplik[0] = "Savaş ve Barış";
        kitaplik[1] = "1984";

        Console.WriteLine(kitaplik[0]); // Savaş ve Barış
        Console.WriteLine(kitaplik[4]); // Boş
        Console.WriteLine(kitaplik[5]); // Hatalı indeks!
    }
}