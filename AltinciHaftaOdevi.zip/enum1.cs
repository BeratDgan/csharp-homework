using System;

enum TrafikIsik
{
    Red,
    Yellow,
    Green
}

class Trafik
{
    public string NeYapmali(TrafikIsik isik)
    {
        switch (isik)
        {
            case TrafikIsik.Red:
                return "Dur!";
            case TrafikIsik.Yellow:
                return "Hazırlan!";
            case TrafikIsik.Green:
                return "Geç!";
            default:
                return "Bilinmeyen durum.";
        }
    }
}

class Program
{
    static void Main()
    {
        Trafik trafik = new Trafik();

        Console.WriteLine(trafik.NeYapmali(TrafikIsik.Red));    // Dur!
        Console.WriteLine(trafik.NeYapmali(TrafikIsik.Yellow)); // Hazırlan!
        Console.WriteLine(trafik.NeYapmali(TrafikIsik.Green));  // Geç!
    }
}