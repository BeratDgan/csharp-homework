using System;

enum CalisanRol
{
    Manager,
    Developer,
    Designer,
    Tester
}

class Calisan
{
    public decimal MaasHesapla(CalisanRol rol)
    {
        switch (rol)
        {
            case CalisanRol.Manager:
                return 15000m; // Manager maaşı
            case CalisanRol.Developer:
                return 12000m; // Developer maaşı
            case CalisanRol.Designer:
                return 10000m; // Designer maaşı
            case CalisanRol.Tester:
                return 9000m;  // Tester maaşı
            default:
                throw new ArgumentException("Geçersiz çalışan rolü.");
        }
    }
}

class Program
{
    static void Main()
    {
        Calisan calisan = new Calisan();

        Console.WriteLine($"Manager maaşı: {calisan.MaasHesapla(CalisanRol.Manager)} TL");
        Console.WriteLine($"Developer maaşı: {calisan.MaasHesapla(CalisanRol.Developer)} TL");
        Console.WriteLine($"Designer maaşı: {calisan.MaasHesapla(CalisanRol.Designer)} TL");
        Console.WriteLine($"Tester maaşı: {calisan.MaasHesapla(CalisanRol.Tester)} TL");
    }
}