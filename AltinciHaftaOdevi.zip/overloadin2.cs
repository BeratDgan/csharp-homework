using System;

class AlanHesaplama
{
    // Karenin alanını hesaplayan metod
    public double Alan(double kenar)
    {
        return kenar * kenar;
    }

    // Dikdörtgenin alanını hesaplayan metod
    public double Alan(double uzunKenar, double kisaKenar)
    {
        return uzunKenar * kisaKenar;
    }

    // Dairenin alanını hesaplayan metod
    public double Alan(double yaricap, bool daireIcin)
    {
        return Math.PI * yaricap * yaricap;
    }
}

class Program
{
    static void Main()
    {
        AlanHesaplama ah = new AlanHesaplama();

        Console.WriteLine("Karenin alanı: " + ah.Alan(5));
        Console.WriteLine("Dikdörtgenin alanı: " + ah.Alan(5, 10));
        Console.WriteLine("Dairenin alanı: " + ah.Alan(7, true));
    }
}