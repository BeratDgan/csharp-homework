using System;

class ZamanHesaplama
{
    // İki tarih arasındaki gün farkını hesaplayan metod
    public int ZamanFarki(DateTime tarih1, DateTime tarih2)
    {
        return (int)(tarih2 - tarih1).TotalDays;
    }

    // İki tarih arasındaki saat farkını hesaplayan metod
    public double ZamanFarkiSaat(DateTime tarih1, DateTime tarih2)
    {
        return (tarih2 - tarih1).TotalHours;
    }

    // İki tarih arasındaki yıl, ay ve gün farkını hesaplayan metod
    public (int Yil, int Ay, int Gun) ZamanFarkiDetayli(DateTime tarih1, DateTime tarih2)
    {
        int yilFarki = tarih2.Year - tarih1.Year;
        int ayFarki = tarih2.Month - tarih1.Month;
        int gunFarki = tarih2.Day - tarih1.Day;

        if (gunFarki < 0)
        {
            ayFarki--;
            gunFarki += DateTime.DaysInMonth(tarih1.Year, tarih1.Month);
        }

        if (ayFarki < 0)
        {
            yilFarki--;
            ayFarki += 12;
        }

        return (yilFarki, ayFarki, gunFarki);
    }
}

class Program
{
    static void Main()
    {
        ZamanHesaplama zh = new ZamanHesaplama();

        DateTime tarih1 = new DateTime(2020, 1, 1);
        DateTime tarih2 = DateTime.Now;

        Console.WriteLine("Gün farkı: " + zh.ZamanFarki(tarih1, tarih2));
        Console.WriteLine("Saat farkı: " + zh.ZamanFarkiSaat(tarih1, tarih2));

        var detayliFark = zh.ZamanFarkiDetayli(tarih1, tarih2);
        Console.WriteLine($"Yıl: {detayliFark.Yil}, Ay: {detayliFark.Ay}, Gün: {detayliFark.Gun}");
    }
}